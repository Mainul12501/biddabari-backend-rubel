<?php

namespace App\Http\Controllers\Frontend\Student;

use App\helper\ViewHelper;
use App\Http\Controllers\Controller;
use App\Models\Backend\BatchExamManagement\BatchExam;
use App\Models\Backend\BatchExamManagement\BatchExamSectionContent;
use App\Models\Backend\BatchExamManagement\BatchExamSubscription;
use App\Models\Backend\Course\Course;
use App\Models\Backend\Course\CourseSection;
use App\Models\Backend\Course\CourseSectionContent;
use App\Models\Backend\ExamManagement\Exam;
use App\Models\Backend\ExamManagement\ExamCategory;
use App\Models\Backend\ExamManagement\ExamOrder;
use App\Models\Backend\OrderManagement\ParentOrder;
use App\Models\Backend\UserManagement\Student;
use App\Models\Frontend\CourseOrder\CourseOrder;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class StudentController extends Controller
{
    protected $data = [], $courseOrders = [], $myCourses = [], $myProfile, $myPayments = [], $loggedUser, $course, $courses = [], $courseSections;
    protected $hasValidSubscription, $exam, $exams = [], $tempExamArray = [], $examOrders = [];
    public function dashboard ()
    {
        $this->courseOrders = CourseOrder::where('user_id', auth()->id())->select('id', 'course_id', 'user_id', 'order_invoice_number', 'paid_amount', 'total_amount', 'status', 'created_at')->with('course:id,title,price,banner,discount_type,slug,status,is_approved')->get();
        if (str()->contains(url()->current(), '/api/'))
        {
            if (str()->contains(url()->current(), '/v1/'))
            {
                return response()->json($this->courseOrders);
            }
        } else {
            return view('frontend.student.dashboard.dashboard', [
                'courseOrders'  => $this->courseOrders,
            ]);
        }
        return 'dashboard page';
    }

    public function myCourses ()
    {
//        $this->courseOrders = CourseOrder::where('user_id', auth()->id())->select('id', 'course_id', 'user_id', 'status')->with('course:id,title,price,banner,discount_type,slug,status,is_approved')->get();
        $this->courseOrders = ParentOrder::where(['user_id'=> auth()->id(), 'ordered_for' => 'course'])->select('id', 'parent_model_id', 'user_id', 'status')->with('course:id,title,price,banner,discount_type,slug,status,is_approved')->get();
        $this->data = [
            'courseOrders'  => $this->courseOrders
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.course.courses');
    }

    public function showCourseContents ($courseId)
    {
//        $this->courseSections = CourseSection::whereCourseId($courseId)->whereStatus(1)->select('id', 'course_id', 'title', 'available_at', 'is_paid')->with(['courseSectionContents' => function($sectionContent){
//            $sectionContent->whereStatus(1)->orderBy('order', 'ASC')->whereIsPaid(1)->get();
//        }])->get();
        $this->course = Course::whereId($courseId)->select('id', 'title', 'slug', 'status')->with(['courseSections' => function($courseSections){
            $courseSections->whereStatus(1)->where('available_at', '<=', Carbon::now()->format('Y-m-d H:i'))->select('id', 'course_id', 'title', 'available_at', 'is_paid')->with(['courseSectionContents' => function($sectionContent){
                $sectionContent->where('available_at', '<=', Carbon::now()->format('Y-m-d H:i'))->whereStatus(1)->orderBy('order', 'ASC')->whereIsPaid(1)->get();
            }])->get();
        }])->first();
        $this->data = [
            'course'    => $this->course
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.course.contents');
    }

    public function showBatchExamContents ($batchExamId, $isMaster , $slug = null)
    {
        if (base64_decode($isMaster) == 1)
        {
            $this->exams    = BatchExam::where('is_master_exam', 0)->whereStatus(1)->select('id', 'title', 'banner', 'slug', 'sub_title', 'is_paid', 'is_featured', 'is_approved', 'status', 'is_master_exam')->get();
            $this->data = [
                'allExams'  => $this->exams,
            ];
        } else {
            $this->exam = BatchExam::whereId($batchExamId)->select('id', 'title', 'slug', 'status')->with(['batchExamSections' => function($batchExamSections){
                $batchExamSections->where('available_at', '<=', Carbon::now()->format('Y-m-d H:i'))->whereStatus(1)->select('id', 'batch_exam_id', 'title', 'available_at', 'is_paid')->with(['batchExamSectionContents' => function($batchExamSectionContents){
                    $batchExamSectionContents->where('available_at', '<=', Carbon::now()->format('Y-m-d H:i') )->whereStatus(1)->orderBy('order', 'ASC')->whereIsPaid(1)->get();
                }])->get();
            }])->first();

            $this->data = [
                'batchExam'    => $this->exam
            ];
        }

        return ViewHelper::checkViewForApi($this->data, 'frontend.student.batch-exam.contents');
    }

    public function myExams ()
    {
        $this->loggedUser = auth()->user();
        $this->exams   = ParentOrder::where(['ordered_for' => 'batch_exam', 'user_id' => $this->loggedUser->id])->with([
            'batchExam' => function($batchExam) {
                $batchExam->whereStatus(1)->select('id', 'title', 'banner', 'slug', 'sub_title', 'is_paid', 'is_featured', 'is_approved', 'status', 'is_master_exam')->first();
            }
        ])->select('id', 'user_id', 'parent_model_id', 'batch_exam_subscription_id', 'ordered_for', 'status')->get();
        foreach ($this->exams as $exam)
        {
            $exam->has_validity = ViewHelper::checkIfBatchExamIsEnrollmentAndHasValidity(auth()->user(), $exam);
            $exam->order_status = ViewHelper::checkUserBatchExamIsEnrollment(auth()->user(), $exam->batchExam);
        }
        $this->data = [
            'exams' => $this->exams
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.my-pages.exams');
    }

    protected function getNestedCategoryExams($examCategory)
    {
        if (!empty($examCategory))
        {
            if (!empty($examCategory->customExamCategories))
            {
                foreach ($examCategory->customExamCategories as $customExamCategory)
                {
                    foreach ($customExamCategory->exams as $exam)
                    {
                        array_push($this->exams, $exam);
                    }
                    $this->getNestedCategoryExams($customExamCategory);
                }
            }
        }
    }

    public function myOrders ()
    {
//        $this->courseOrders = CourseOrder::where('user_id', auth()->id())->select('id', 'course_id', 'user_id', 'status')->with('course:id,title,price')->get();
        $this->courseOrders = ParentOrder::where(['user_id' => auth()->id()])->select('id', 'parent_model_id', 'user_id', 'order_invoice_number', 'ordered_for', 'total_amount', 'paid_amount', 'payment_status', 'status')->with('course:id,title,price', 'batchExam:id,title,price')->get();
        $this->data = [
            'orders'  => $this->courseOrders
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.my-pages.orders');
    }

    public function viewProfile ()
    {
        $isStudent = false;
        $user = auth()->user();
        if (!empty($user->roles))
        {
            foreach ($user->roles as $role)
            {
                if ($role->id == 4)
                {
                    $isStudent = true;
                }
            }
        }
        if ($isStudent)
        {
            $this->data = [
                'student'   => Student::whereUserId($user->id)->first(),
                'user'      => $user
            ];
            return ViewHelper::checkViewForApi($this->data, 'frontend.student.my-pages.profile');
        } else {
            if (str()->contains(url()->current(), '/api/'))
            {
                return response()->json(['error' => 'Login as a student to view this page']);
            }
            return back()->with('error', 'Login as a student to view this page');
        }

    }

    public function profileUpdate (Request $request)
    {
        $isStudent = false;
        $user = auth()->user();
        if (!empty($user->roles))
        {
            foreach ($user->roles as $role)
            {
                if ($role->id == 4)
                {
                    $isStudent = true;
                }
            }
        }
        if ($isStudent)
        {
            Student::createOrUpdateStudent($request, $user, Student::where('user_id', $user->id)->first()->id);
            User::updateStudent($request, auth()->id());
            if (str()->contains(url()->current(), '/api/'))
            {
                return response()->json(['success' => 'Profile Updated successfully.']);
            }
            return back()->with('success', 'Profile Updated successfully.');
        } else {
            return back()->with('error', 'Login as a student to update from this page');
        }
    }

    public function showPdf($contentId)
    {
        $this->data = [
            'sectionContent'  => CourseSectionContent::whereId($contentId)->select('id', 'course_section_id', 'content_type', 'title', 'pdf_link', 'pdf_file', 'status')->first(),
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.course.contents.pdf');
    }

    public function showBatchExamPdf($contentId)
    {
        $this->data = [
            'sectionContent'  => BatchExamSectionContent::whereId($contentId)->select('id', 'batch_exam_section_id', 'content_type', 'title', 'pdf_link', 'pdf_file', 'status')->first(),
        ];
        return ViewHelper::checkViewForApi($this->data, 'frontend.student.batch-exam.contents.pdf');
    }

    public function studentChangePassword ()
    {
        return view('frontend.student.my-pages.password');
    }

    public function getTextTypeContent (Request $request)
    {
        try {
            return view('frontend.student.course.contents.show-content-ajax', [
                'content'   => CourseSectionContent::find($request->content_id),
            ]);
        } catch (\Exception $exception)
        {
            return response()->json($exception->getMessage());
        }

//        return response()->json(CourseSectionContent::find($request->content_id));
    }

    public function getBatchExamTextTypeContent (Request $request)
    {
        try {
            return view('frontend.student.batch-exam.contents.show-content-ajax', [
                'content'   => BatchExamSectionContent::find($request->content_id),
            ]);
        } catch (\Exception $exception)
        {
            return response()->json($exception->getMessage());
        }
    }
}
