<?php

namespace App\Http\Controllers\Backend\ProductManagement;

use App\Http\Controllers\Controller;
use App\Models\Backend\ProductManagement\Product;
use App\Models\Backend\ProductManagement\ProductAuthor;
use App\Models\Backend\ProductManagement\ProductCategory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public $product;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.product-management.product.index', [
            'products'    => Product::all(),
            'productCategories'  => ProductCategory::whereStatus(1)->get(),
            'productAuthors'  => ProductAuthor::whereStatus(1)->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'product_category_id' => 'required',
            'product_author_id' => 'required',
            'title' => 'required',
            'image' => 'nullable|image',
            'featured_pdf'  => 'nullable|mimes:pdf',
            'price' => 'required',
            'stock_amount'  => 'required',
        ]);
        try {
            $this->product = Product::saveOrUpdateProduct($request);
            $this->product->productCategories()->sync($request->product_category_id);
            return back()->with('success', 'Product Created Successfully.');
        } catch (\Exception $exception)
        {
            return back()->with('error', $exception->getMessage());
        }


    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return response()->json(Product::whereId($id)->with('productCategories:id,name,status')->first());
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'product_category_id' => 'required',
            'product_author_id' => 'required',
            'title' => 'required',
            'image' => 'nullable|image',
            'featured_pdf'  => 'nullable|mimes:pdf',
            'price' => 'required',
            'stock_amount'  => 'required',
        ]);
        try {
            $this->product = Product::saveOrUpdateProduct($request,$id);
            $this->product->productCategories()->sync($request->product_category_id);
            return back()->with('success', 'Product Update Successfully.');
        } catch (\Exception $exception)
        {
            return back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->product = Product::find($id);
        if (file_exists($this->product->image))
        {
            unlink($this->product->image);
        }
        if (file_exists($this->product->featured_pdf))
        {
            unlink($this->product->featured_pdf);
        }
        $this->product->delete();
        return back()->with('success', 'product Deleted Successfully.');
    }
}
